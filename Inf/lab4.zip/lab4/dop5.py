from aspose.cells import Workbook

workbook = Workbook("Inf/lab4/lessons.xml")
workbook.save("Inf/lab4/lessons.csv")