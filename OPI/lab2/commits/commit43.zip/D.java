public class D extends null {

    private double b = 100.500;

    private int i = 42;

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public String kk() {
        return "Hello world";
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public Object gg() {
        return new java.util.Random();
    }

    public float ff() {
        return 0;
    }

    public int af() {
        return -1;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public long dd() {
        return 33;
    }

    public byte oo() {
        return 1;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public void aa() {
        System.out.println("void aa");
    }

    public int cc() {
        return 42;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public long ac() {
        return 111;
    }

    public double ee() {
        return 100.500;
    }

    public Object rr() {
        return null;
    }
}
