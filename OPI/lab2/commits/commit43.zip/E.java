public class E extends null {

    byte oo();

    long ac();

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public float ff() {
        return 0;
    }
}
