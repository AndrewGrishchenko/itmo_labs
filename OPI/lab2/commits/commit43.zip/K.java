public class K extends null {

    private long k = 4321;

    private byte f = 1;

    public void bb() {
        System.out.println(42);
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public long ac() {
        return 111;
    }

    public Object pp() {
        return this;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public long dd() {
        return 100500;
    }

    public void ab() {
        System.out.println();
    }

    public int af() {
        return -1;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public double ee() {
        return java.lang.Math.PI;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public float ff() {
        return 3.14;
    }

    public String kk() {
        return "Hello world";
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public double ad() {
        return 12.12;
    }

    public void aa() {
        System.out.println("void aa");
    }

    public int cc() {
        return 39;
    }

    public byte oo() {
        return 3;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public Object rr() {
        return null;
    }
}
