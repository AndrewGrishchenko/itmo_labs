public class B extends null implements E {

    private String e = "test";

    private double b = 100.500;

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public byte oo() {
        return 4;
    }

    public long ac() {
        return 222;
    }

    public int ae() {
        return 9;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public void ab() {
        System.out.println();
    }

    public Object pp() {
        return this;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public float ff() {
        return 3.14;
    }

    public int cc() {
        return 42;
    }

    public String kk() {
        return "Yes";
    }

    public long dd() {
        return 100500;
    }

    public double ad() {
        return 11.09;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public double ee() {
        return 100.500;
    }

    public Object rr() {
        return null;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public void aa() {
        return;
    }
}
