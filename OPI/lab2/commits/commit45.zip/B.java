public class B extends null implements E {

    private String e = "test";

    private double b = 100.500;

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public byte oo() {
        return 4;
    }

    public long ac() {
        return 222;
    }

    public int ae() {
        return 9;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public void ab() {
        return;
    }

    public Object pp() {
        return this;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int af() {
        return -1;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public long dd() {
        return 33;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public double ad() {
        return 11;
    }

    public int cc() {
        return 42;
    }

    public String kk() {
        return "Yes";
    }

    public double ee() {
        return 100.500;
    }

    public Object rr() {
        return null;
    }

    public float ff() {
        return 3.14;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
