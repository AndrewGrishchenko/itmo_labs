public class B extends null implements E {

    private String e = "test";

    private double b = 100.500;

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public byte oo() {
        return 4;
    }

    public long ac() {
        return 222;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public Object pp() {
        return this;
    }

    public int ae() {
        return 9;
    }

    public void ab() {
        return;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public String kk() {
        return "Hello world";
    }

    public long dd() {
        return 100500;
    }

    public int af() {
        return -1;
    }

    public double ee() {
        return 500.100;
    }

    public float ff() {
        return 3.14;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public double ad() {
        return 11.09;
    }
}
