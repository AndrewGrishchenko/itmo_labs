public class D extends null {

    private double b = 100.500;

    private int i = 42;

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public Object gg() {
        return new java.util.Random();
    }

    public float ff() {
        return 0;
    }

    public String kk() {
        return "Hello world";
    }

    public int af() {
        return -1;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public void ab() {
        System.out.println();
    }

    public long ac() {
        return 222;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public long dd() {
        return 100500;
    }
}
