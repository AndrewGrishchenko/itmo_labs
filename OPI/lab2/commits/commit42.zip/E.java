public class E extends null {

    byte oo();

    long ac();

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }
}
