public class D extends null {

    private double b = 100.500;

    private int i = 42;

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public String kk() {
        return "Hello world";
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public float ff() {
        return 0;
    }

    public int af() {
        return -1;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public byte oo() {
        return 1;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public long ac() {
        return 111;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }
}
