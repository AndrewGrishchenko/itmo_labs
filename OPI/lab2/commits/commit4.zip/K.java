public class K {

    private long k = 4321;

    private byte f = 1;

    public void bb() {
        System.out.println(42);
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}
