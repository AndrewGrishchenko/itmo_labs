public interface E {

    byte oo();

    long ac();
}
