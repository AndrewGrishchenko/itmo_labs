public class B implements E {

    private String e = "test";

    private double b = 100.500;

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public byte oo() {
        return 4;
    }

    public long ac() {
        return 222;
    }

    public int ae() {
        return 9;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public void ab() {
        return;
    }

    public Object pp() {
        return this;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public float ff() {
        return 0;
    }

    public int cc() {
        return 13;
    }
}
