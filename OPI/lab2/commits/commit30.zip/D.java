public class D {

    private double b = 100.500;

    private int i = 42;

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public String kk() {
        return "Hello world";
    }

    public void bb() {
        System.out.println(getClass().getName());
    }
}
