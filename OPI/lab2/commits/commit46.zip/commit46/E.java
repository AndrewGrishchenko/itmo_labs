public class E extends null {

    byte oo();

    long ac();

    public void aa() {
        return;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }
}
