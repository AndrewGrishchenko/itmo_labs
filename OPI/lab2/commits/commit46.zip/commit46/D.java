public class D extends null {

    private double b = 100.500;

    private int i = 42;

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public String kk() {
        return "Hello world";
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public float ff() {
        return 0;
    }

    public int af() {
        return -1;
    }

    public long dd() {
        return 33;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public Object rr() {
        return null;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public byte oo() {
        return 1;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public long ac() {
        return 333;
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public double ee() {
        return 100.500;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public void ab() {
        System.out.println();
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }
}
