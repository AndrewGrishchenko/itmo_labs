public class K {

    private long k = 4321;

    private byte f = 1;

    public void bb() {
        System.out.println(42);
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public long ac() {
        return 111;
    }

    public Object pp() {
        return this;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public double ee() {
        return java.lang.Math.PI;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }
}
