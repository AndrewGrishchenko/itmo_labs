public class B extends null implements E {

    private String e = "test";

    private double b = 100.500;

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public byte oo() {
        return 4;
    }

    public long ac() {
        return 222;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public int ae() {
        return 9;
    }

    public void ab() {
        return;
    }

    public Object pp() {
        return this;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public int af() {
        return -1;
    }

    public String kk() {
        return "Hello world";
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }
}
