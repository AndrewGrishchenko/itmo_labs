public class E extends null {

    byte oo();

    long ac();
}
